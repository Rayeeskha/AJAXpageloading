<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
 class Category_Controller extends CI_Controller
 {
 	
 		public function index(){
 			$this->load->view("menu");
 		}
 		public function items(){
 			$this->load->view("items");
 		}
 		public function category(){
 			$this->load->view("category");

 			






 		}
 }


?>