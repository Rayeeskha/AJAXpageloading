</div>
<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/jquery-ui.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/validate.jquery.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/validate.additional-methods.min.js') ?>"></script>
<script language="JavaScript" src="https://cdn.datatables.net/1.10.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script language="JavaScript" src="https://cdn.datatables.net/plug-ins/3cfcc339e89/integration/bootstrap/3/dataTables.bootstrap.js" type="text/javascript"></script>

</body>
</html>