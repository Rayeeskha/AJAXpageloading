<?php include "header.php"; ?>

<div class="icons">
    <div class="hidden-sm hidden-xs">
    	<div class="container">
    		<nav class="mainMenu1">
        		<ul class="mainMenu text-center">
        			<?php $baseName = basename( $_SERVER['PHP_SELF'] ); $color = 'style="color: #24B314"'; ?>
                    
        			<li><a href="<?php echo base_url(); ?>Category_Controller/category"><i class="fa fa-sitemap" <?= preg_match("/categories/", $baseName ) ? $color : ''; ?>> </i><p>Categories</p></a></li>

        			<li><a href="<?php echo base_url(); ?>Category_Controller/items" <?= preg_match("/items/", $baseName ) ? $color : ''; ?> ><i class="fas fa-luggage-cart"></i><p>Items</p></a></li>

        		</ul>
        		<div class="clearfix"></div>
        	</nav>
        </div>
    	<!--<div class="navBtn pull-right"><i class="fas fa-caret-square-down navBtnAct"></i></div>-->
    	<div class="clearfix"></div>
	</div>


  <div class="container" style="margin-top: 20px;">
        <div class="hidden-md hidden-lg visible-sm visible-xs">
            <button type="button" class="btn dropdown-toggle btn-primary pull-right mobileMenu_btn" data-toggle="dropdown" >
                <i class="fa fa-bars" aria-hidden="true"></i>
            </button>
            <div class="dropdown-menu pull-right" style="top:4%;right: 7px;">
                <nav class="mainMenu1 mobileMenu">
                    <ul class="mainMenu">
                    	<?php $baseName = basename( $_SERVER['PHP_SELF'] ); $color = 'style="color: #24B314"'; ?>
                    	<li><a href="<?php echo base_url(); ?>Category_Controller/items"><i class="fas fa-utensils" <?= preg_match("/items/", $baseName ) ? $color : ''; ?> ></i><span>Items</span></a></li>
                        <li><a href="<?php echo base_url(); ?>Category_Controller/category"><i class="fa fa-sitemap" <?= preg_match("/categories/", $baseName ) ? $color : ''; ?>> </i><span>Categories</span></a></li>


                   </ul>
            <div class="clearfix"></div>
        </nav>
            </div>
        </div>
    </div>
</div>
<?php include "footer.php"; ?>








	