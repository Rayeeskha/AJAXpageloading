
<?php include "menu.php"; ?>	


<section class="mainContentDIV container-fluid">		

	<div class="container-fluid mainContent mainPages">
		<div class="row">
			<div class="BtnsList">
				<ul>
					<li><a href="#" class="btn btn-primary btn-xs" data-title="Add" data-toggle="modal" data-target="#addItems" >Add New Items</a></li>
				</ul>
				<div class="clearfix"></div>
			</div>
			<div class="col-md-12">
				<table id="datatable" class="table table-striped table-bordered" cellspacing="0" width="100%">
					<thead>
						<tr>
							<th>Item Name</th>
							<th>Code</th>
							<th>Category Name</th>
							<th>Stock</th>
							<th>Item Description</th>
							
							<th>Image</th>
							<th>View</th>
							<th>Status</th>
							<th>Actions</th>
						</tr>
					</thead>
					<tbody id="getItemData">
						
							<tr>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>

								
							
							    
								<td><img src="" class="img-responsive" width="100px; height:100px;"></td>
								
								
							    <td><a href="image.php" class="btn btn-primary">View</a></td>




								<td></td>



						  </div>
								<td>
									<a href="#" class="btn btn-primary btn-xs editItem"  data-title="Edit"><span class="far fa-edit"></span></a>
									
									<a href="#" class="btn btn-danger btn-xs deleteItem"  data-title="Delete"><span class="far fa-trash-alt"></span></a>
								</td>
							</tr>
							<!-- Modal -->


						    
						
					</tbody>
				</table>


			</div>
		</div>


		
		<!-- model pop up for Edit Category -->
		<div class="modal fade model-popup-custom" id="editItem" tabindex="-1" role="dialog" data-backdrop="false" aria-labelledby="myLargeModalLabel">
			<div class="modal-dialog modal-md" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<!--<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
						<h4 class="modal-title" id="myModalLabel">Update Item</h4>
					</div>
					<form action="" method="post" autocomplete="off" id="editItemForm" enctype="multipart/form-data">
						<input type="hidden" class="form-control itemId" id="iId" name="iId" placeholder="Item Id" />
						<div class="modal-body editItemDetails">
							<div class="form-group">
								<label for="cContact">Select Category</label>
								<select class="form-control categoryListJs" id="category" name="category"></select>
							</div>
							<div class="form-group">
								<label for="cFullname">Item Name</label>
								<input type="text" class="form-control itemName" id="itemName" name="itemName" placeholder="Item Name" />
							</div>
							<div class="form-group">
								<label for="cFullname">Item Code</label>
								<input type="text" class="form-control itemCode" id="itemCode" name="itemCode" placeholder="Item Code" />
							</div>
							<div class="form-group">
								<label for="cFullname">Added Date</label>
								<input type="text" class="form-control getDate" id="date" name="date" placeholder="Select Date" />
							</div>
							<div class="form-group">
								<label for="cFullname">Stock</label>
								<div class="row">
									<div class="radio col-md-6 col-lg-6 col-sm-6 col-xs-12">
									    <label><input type="radio" name="stock" id="stock1" value="∞" class="radiobtnJs"> ∞ (Unlimited)</label>
									</div>
									<div class="radio col-md-6 col-lg-6 col-sm-6 col-xs-12" style="margin-top: 10px;">
									    <label><input type="radio" name="stock" id="stock2" value="" class="stock_value"><input type="text" class="form-control stockval" id="edit_stockval" name="" placeholder="stock" /></label>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label for="cEmail">Item Description</label>
								<textarea class="form-control description" id="description" name="description" placeholder="Description" rows="2"></textarea>
							</div>
							
							
							<div class="form-group">
								<label for="cContact">Select Kitchen</label>
								<select class="form-control kitchenListJs" id="kitchen" name="kitchen"></select>
							</div>
							
							<div class="form-group">
								<label for="cContact">Status</label>
								<select class="form-control statusListJs" id="statusList" name="statusList"></select>
							</div>
							<div class="input-group">
								Select Image : <input type="file" class="custom-file-input itemFile" id="itemFile" name="itemFile" />
							</div><br>

							<!----Multiple upload file section ------>
							
							<div class="input-group">
								<form action="http://localhost/login%20(4)/login/items/_edit_items" enctype="multipart/form-data" method="post" accept-charset="utf-8">
								<label>Multiple Upload File</label><input type="file" name="file[]"  multiple /><br>
								<input type="submit" value="Upload" class="btn btn-default" />
								</form>
							</div>




						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default billBtnCancel" data-dismiss="modal">Close</button>
							<button type="submit" class="btn btn-primary billBtn update">Update</button>
						</div>
					</form>
				</div>
			</div>
		</div>		
		
		<!-- model pop up for Add Category -->
		<div class="modal fade model-popup-custom" id="addItems" tabindex="-1" role="dialog" data-backdrop="false" aria-labelledby="myLargeModalLabel">
			<div class="modal-dialog modal-md" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<!--<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->

						<h4 class="modal-title" id="myModalLabel">Add Items</h4>
					</div>
					<div class="responseResult text-center"></div>
					<form action="" method="post" autocomplete="off" id="addItemsForm" enctype="multipart/form-data">
						<div class="modal-body">
							
							<div class="form-group">
								<label for="cFullname">Item Name</label>
								<input type="text" class="form-control" id="itemName" name="itemName" placeholder="Item Name" />
							</div>
							<div class="form-group">
								<label for="cFullname">Item Code</label>
								<input type="text" class="form-control" id="itemCode" name="itemCode" placeholder="Item Code" />
							</div>
							<div class="form-group">
								<label for="cFullname">Stock</label>
								<div class="row">
									<div class="radio col-md-6 col-lg-6 col-sm-6 col-xs-12">
									    <label><input type="radio" name="stock" id="stocks1" value="∞" checked> ∞ (Unlimited)</label>
									</div>
									<div class="radio col-md-6 col-lg-6 col-sm-6 col-xs-12" style="margin-top: 10px;">
									    <label><input type="radio" name="stock" id="stocks2" value="" class="stock_value"><input type="text" class="form-control" id="stockval" name="" placeholder="stock" /></label>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label for="cEmail">Item Description</label>
								<textarea class="form-control description" id="description" name="description" placeholder="Description" rows="2"></textarea>
							</div>
							
							
							
							
							<div class="form-group">
								<div class="row">
									<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 ">
										<label for="cContact">Item Price</label>
									</div>
									
								</div>
								
								<div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12 ">
									
								</div>
								<div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12 flr_types_price">
									<input type="text" class="form-control" id="dine_price" name="dinePrice" placeholder="Item Price" />
									
								</div>															
							</div>
							
							
							
							<div class="form-group">
								<label for="cContact">Status</label>
								<select class="form-control" id="statusList" name="statusList">
								
								</select>
							</div>

							<div class="input-group">
								<label for="cContact">Select Image :</label> <input type="file" class="custom-file-input" id="itemFile" name="itemFile" />
							</div><br>

							<form action="http://localhost/login%20(4)/login/items/_edit_items" enctype="multipart/form-data" method="post" accept-charset="utf-8">
							<label>Multiple Upload Image</label><input type="file" name="file[]"  multiple /><br>
							<input type="submit" value="Upload" class="btn btn-default" />
							</form>

						<div class="modal-footer">
							<button type="button" class="btn btn-default billBtnCancel" data-dismiss="modal">Close</button>
							<button type="submit" class="btn btn-primary billBtn submit">Add</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</section>


<script type="text/javascript">
	$(document).ready( function () {
    $('#datatable').DataTable();
} );

</script>
