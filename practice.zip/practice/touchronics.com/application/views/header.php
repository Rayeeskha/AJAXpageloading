<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="author" content="">
	<title>Touchronics.com</title>
	<link rel="icon" href="<?php ('assets/images/touchronicslogo.png'); ?>" type="" sizes="16x16" />
	
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/jquery-ui.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap-theme.min.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/fonts/iconic/css/material-design-iconic-font.min.css'); ?>">
	
	<link rel="stylesheet" href="//use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous" />

	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/plug-ins/3cfcc339e89/integration/bootstrap/3/dataTables.bootstrap.css">

	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/styles.min.css'); ?>">

	
</head>
<body>

	<header class="header"><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<aside class="col-md-2 col-lg-2 col-sm-2 col-xs-3 logo">
		<a href="#"><img src="<?php echo base_url('assets/images/touchcronics.png') ?>" class="logoImg img-responsive" /></a>
	</aside>

	

	 

	   



