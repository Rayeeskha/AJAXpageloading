<?php include "menu.php"; ?>
<section class="mainContentDIV container-fluid">		
	
	<div class="container-fluid mainContent mainPages">
		<div class="row">
			<div class="BtnsList">
				<ul>
					<li><a href="#" class="btn btn-primary btn-xs" data-title="Add" data-toggle="modal" data-target="#addCat">Add New Category</a></li>
					<li style="float: right"><a href="cuisine.php" class="btn btn-primary btn-xs">View Cuisine</a></li>
				</ul>
				<div class="clearfix"></div>
			</div>
			<div class="col-md-12">
				<table id="datatable" class="table table-striped table-bordered" cellspacing="0" width="100%">
					<thead>
						<tr>
							<th>Category Name</th>
							<th>Category Code</th>
							<th>Description</th>
							<th>Category logo</th>
							<th>Status</th>
							<th>Actions</th>
						</tr>
					</thead>
					<tbody id="getCatData">
						
							<tr>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td>
									<a href="#" class="btn btn-primary btn-xs editCat"data-title="Edit" data-toggle="modal" ><span class="far fa-edit"></span></a>
									<a href="#" class="btn btn-danger btn-xs deleteCat" data-title="Delete"><span class="far fa-trash-alt"></span></a>
								</td>
							</tr>
						
					</tbody>
				</table>
			</div>
		</div>
		
	
		
		
		<!-- model pop up for Add Category -->
		<div class="modal fade model-popup-custom" id="addCat" tabindex="-1" role="dialog" data-backdrop="false" aria-labelledby="myLargeModalLabel">
			<div class="modal-dialog modal-md" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<!--<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
						<h4 class="modal-title" id="myModalLabel">Add Category</h4>
					</div>
					<div class="responseResult text-center"></div>
					<form action="" method="post" autocomplete="off" id="addCatForm">
						<div class="modal-body">
							<div class="form-group">
								<label for="cFullname">Category Name</label>
								<input type="text" class="form-control" id="catName" name="catName" placeholder="Category Name" />
							</div>
							<div class="form-group">
								<label for="cCode">Category Code</label>
								<input type="text" class="form-control" id="cCode" name="catName" placeholder="Category Code" />
							</div>
							<div class="form-group">
								<label for="cEmail">Description</label>
								<textarea class="form-control description" id="description" name="description" placeholder="Description" rows="2"></textarea>
							</div>
                            <div class="form-group">
								<label for="cContact">Serves in</label>
								<select class="form-control serves_in" id="serves_in" name="serves_in">
								    <option value=""> Select</option>
									<option value="Cosmatics">Cosmatics</option>
                                    <option value="Jewellery">Jewellery</option>
                                    <option value="Cloths">Cloths</option>
                                    <option value="Accessories">Accessories</option>
								</select>
							</div>
				
							<div class="form-group">
								<label for="cContact">Status</label>
								<select class="form-control" id="statusList" name="statusList">
									<option>Select</option>
									<option>Availabel</option>
									<option>Not Available</option>
									
								</select>
							</div>

						<form action="" enctype="multipart/form-data" method="post" accept-charset="utf-8">
								<label>Upload Logo</label><input type="file" name="file"  />
								<!-- <input type="submit" value="Upload"  /> -->
						</form>	
							
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default billBtnCancel" data-dismiss="modal">Close</button>
							<button type="submit" value="Upload"  class="btn btn-primary billBtn">Add</button>
						</div>
					</form>
				</div>
			</div>
		</div>
		
	</div>
</section>

<script type="text/javascript">
	$(document).ready( function () {
    $('#datatable').DataTable();
} );

</script>
