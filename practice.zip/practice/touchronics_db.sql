-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 20, 2020 at 01:55 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `touchronics_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `item_category_list`
--

CREATE TABLE `item_category_list` (
  `CATEGORY_ID` bigint(20) NOT NULL,
  `CATEGORY_NAME` varchar(555) NOT NULL,
  `CATEGORY_CODE` int(11) NOT NULL,
  `DESCRIPTION` text NOT NULL,
  `SERVES` varchar(55) NOT NULL,
  `IMAGE` blob NOT NULL,
  `STATUS_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `status_list`
--

CREATE TABLE `status_list` (
  `STATUS_ID` bigint(20) NOT NULL,
  `STATUS` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `status_list`
--

INSERT INTO `status_list` (`STATUS_ID`, `STATUS`) VALUES
(0, 'Not Available'),
(1, 'Available');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `item_category_list`
--
ALTER TABLE `item_category_list`
  ADD PRIMARY KEY (`CATEGORY_ID`),
  ADD KEY `STATUS_ID` (`STATUS_ID`);

--
-- Indexes for table `status_list`
--
ALTER TABLE `status_list`
  ADD PRIMARY KEY (`STATUS_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `item_category_list`
--
ALTER TABLE `item_category_list`
  MODIFY `CATEGORY_ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `status_list`
--
ALTER TABLE `status_list`
  MODIFY `STATUS_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10003;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `item_category_list`
--
ALTER TABLE `item_category_list`
  ADD CONSTRAINT `item_category_list_ibfk_1` FOREIGN KEY (`CATEGORY_ID`) REFERENCES `status_list` (`STATUS_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
